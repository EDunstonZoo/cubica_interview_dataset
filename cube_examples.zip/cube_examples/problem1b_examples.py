

input1_towers = [1, 2, 2, 2, 5, 6]
input1_viewer = 1
output1 = 0

input2_towers = input1_towers
input2_viewer = 2
output2 = 1

input3_towers = input1_towers
input3_viewer = 3
output3 = 4

input4_towers = input1_towers
input4_viewer = 5
output4 = 4

input5_towers = [int(l) for l in open("problem1b_example_input.txt")]
input5_viewer = 999
output5 = 999998
