
input1_towers = [3, 1, 5, 3, 2, 4, 2, 6, 1]
input1_viewer = 4
output1 = 2

input2_towers = input1_towers
input2_viewer = 5
output2 = 2

input3_towers = input1_towers
input3_viewer = 6
output3 = 7

input4_towers = [int(l) for l in open("problem1a_example_input.txt")]
input4_viewer = 999
output4 = 999998
