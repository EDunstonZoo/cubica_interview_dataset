
input1 = [3, 1, 5, 3, 2, 4, 2, 6, 1]
output1 = 11

input2 = [int(l) for l in open("problem2_example_input.txt")]
output2 = 500227625
